////// Compile this file only for the device /////
#ifdef __HERO_1

/////////////////////////////////
//          KERNELS            //
/////////////////////////////////

#define CORES 8

void dev_matvec(uint32_t x_out_phys, uint32_t w_phys, uint32_t x_phys, uint32_t n, uint32_t d) {

    // Verify we don't receive nullptrs
    if (!n || !d || !x_out_phys || !x_phys || !w_phys)
        goto omp_exit;

    // Veirfy the input and output data are in device memory
    if(dev_check_transfer(x_out_phys, x_phys, n*d))
        goto omp_exit;

    // Allocate buffers to hold x (vector) and up to 8 rows
    __device uint32_t *x_l1;
    x_l1 = (__device uint32_t *) snrt_l1alloc(n * sizeof(uint32_t));
    __device uint32_t *w_row_l1;
    w_row_l1 = (__device uint32_t *) snrt_l1alloc(CORES * n * sizeof(uint32_t));

    // Copy the vector locally
    dev_dma_memcpy(x_l1, (const __device void*)x_phys, n * sizeof(uint32_t));
    dm_wait();

    int it = 0;

    // Loop over the rows 8 per 8
    for (int I = 0; I < d; I += CORES) {
        int rows_left = d - I;
        
        // Copy the newt 8 rows
        dev_dma_memcpy(w_row_l1, (__device void*)(w_phys + n * sizeof(uint32_t) * I), n * MIN(rows_left, CORES) * sizeof(uint32_t));
        dm_wait();

#pragma omp parallel for
        for (int i = 0; i < CORES; i++) {
            uint32_t val = 0.0f;
            if (I + i >= d)
                goto end;

            // Compute the dotproduct
            for (int j = 0; j < n; j++) {
                val += x_l1[j] * w_row_l1[j + snrt_cluster_core_idx() * n];
            }
            // Store the result
            ((uint32_t *)x_out_phys)[i + I] = val;
        end:;
        }
        it++;
    }
    omp_exit: ;
}

#endif
