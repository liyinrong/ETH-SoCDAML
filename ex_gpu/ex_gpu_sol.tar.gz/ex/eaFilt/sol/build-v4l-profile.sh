#!/bin/bash

#gcc main.cpp -L/usr/local/cuda-7.0/targets/armv7-linux-gnueabihf/lib \
#-lopencv_calib3d -lopencv_contrib -lopencv_core -lopencv_features2d -lopencv_flann -lopencv_gpu -lopencv_highgui \
#-lopencv_imgproc -lopencv_legacy -lopencv_ml -lopencv_objdetect -lopencv_photo -lopencv_stitching -lopencv_superres \
#-lopencv_ts -lopencv_video -lopencv_videostab -lopencv_detection_based_tracker -lopencv_esm_panorama -lopencv_facedetect \
#-lopencv_imuvstab -lopencv_tegra -lopencv_vstab \
#-lstdc++ \
#-o main.x

#gcc main.cpp -L/usr/local/cuda-7.0/targets/armv7-linux-gnueabihf/lib \
#-lopencv_calib3d -lopencv_contrib -lopencv_core -lopencv_features2d -lopencv_flann -lopencv_gpu -lopencv_highgui \
#-lopencv_imgproc -lopencv_legacy -lopencv_ml -lopencv_objdetect -lopencv_photo -lopencv_stitching -lopencv_superres \
#-lopencv_ts -lopencv_video -lopencv_videostab -lopencv_detection_based_tracker -lopencv_esm_panorama -lopencv_facedetect \
#-lopencv_imuvstab -lopencv_tegra -lopencv_vstab -lcufft -lnpps -lnppi -lnppc -lcudart -ltbb -lrt -lpthread -lm -ldl \
#-o main.x




nvcc main.cu `pkg-config --libs opencv` -lm -lstdc++ -o main.x -D TX1 -O3 --use_fast_math -arch compute_52 -code sm_53 -pg
#gcc main.cpp `pkg-config --libs opencv` -lm -lstdc++ -o main.x -D TX1 -O3 -pg
./main.x imageNoShow images/car.jpg
#gprof ./main.x
valgrind --tool=callgrind --callgrind-out-file=callgrind-cpu.out ./main.x imagesNoShow images/car.jpg
kcachegrind callgrind-cpu.out
