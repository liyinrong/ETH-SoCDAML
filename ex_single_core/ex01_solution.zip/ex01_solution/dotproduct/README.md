# Dot Product C program

This application contain a simple dot product function between 2 byte-vectors of 1000 elements.

The innermost kernel is written in assembler to give you the whole control of the instructions
executed by the core.

For a quick guide to use assembler in GCC have a look at https://gcc.gnu.org/onlinedocs/gcc/Extended-Asm.html

```
Compile the application (make clean all)
Generate the assember (make dis > dis.s)
Run it in gui mode (make conf gui=1 run)
```

Identify the dot product parts in the assembler.
After executing the code, check both the trace file in ./build/pulpissimo/trace_core_1f_0.log to see the instructions executed by the core.
Can you find the dot product part?

```
How many cycles do you exept from such function? Why?
```

**Sol** The dotproduct function does not immediately start to execute its core operations (indeed, the dot product operation). 
Some instructionss are spent at the beginning to initialize the Control and Status Registers (cssr) that will activate the hardware performance counters implemented in the core. 
These counters starts counting the performance under interest only between `rt_perf_start` and `rt_perf_end`.
As a matter of facts, the instructions that you should not count for the actual `dotproduct` operation performances are:

1. The instructions between cssr initalization and the starts of the hardware loop;
2. The instructions between the end of the hardware loop and the end of the function;

## Loop Unrolling

Improve the application using the loop unrolling technique we have seen at the lecture.
Complete the provided function and repeat the step above.

```
How many cycles do you exept from such function?
Analyze the trace around your function. Where is the stall?
Introduce the c.nop instruction to align the address of the first instruction of the HWloop to get best performance.
```

**Sol** Please see the answer above for the forst question 
For what concerns the `c.nop` operation (= no operation, i.e. a stall, or a bubble: a clock cycle where nothing is going to be done), note that fetching a 32-bit misaligned instruction 
(i.e. whenever the address is not a multiple of 4) requires two cycles. A `c.nop` instruction is needed to align the address of the first instruction in the hardware loop. 
When this is not done (you uncomment `ifdef ADDNOP` in the code), you will see that there will actually be one instruction stall added for each cycle of the loop. These stalls come from the two-cycle fetching mentioned above.
Add the `c.nop` to avoid the aforementioned instruction stalls. In the `performance_counters_sol.pdf` file, we have printed the solutions you should obtain with and without `c.nop` instruction.


## Use of the SIMD instructions

Rewrite the function to implement the dot product using the sum of dot product function
that you find the PULP extensions of the RI5CY core (in its user_manual.doc)

```
Complete the function.
How many cycles do you exept from such function?
Fix the HWloop first instruction address if needed.
What is the speed up?
```

**Sol** Please see the first answer to this question